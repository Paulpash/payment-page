import axios from axios
     // Initialize the Airtel Money SDK
    AirtelMoneySDK.initialize({
      clientId: 'f472ca91-33cf-462f-9e31-47e7edff2a1a',
      apiKey: '****************************',
      environment: 'stagging' // Or 'production' for the live environment
    });

    // Add an event listener to the payment button
    const paymentButton = document.getElementById('paymentButton');
    paymentButton.addEventListener('click', function() {
      // Make a payment using Airtel Money
      makeAirtelMoneyPayment();
    });

    function makeAirtelMoneyPayment() {
      // Construct the payment request with required parameters
      const paymentRequest = {
        amount: 1000,
        phoneNumber: 'CUSTOMER_PHONE_NUMBER',
        reference: 'PAYMENT_REFERENCE'
        // Add any other required parameters
      };

      // Call the Airtel Money SDK method to initiate the payment
      AirtelMoneySDK.makePayment(paymentRequest)
        .then(function(response) {
          // Handle the payment response
          if (response.success) {
            // Payment was successful
            displayPaymentSuccess();
          } else {
            // Payment failed
            displayPaymentError(response.errorMessage);
          }
        })
        .catch(function(error) {
          // Handle any errors
          displayPaymentError(error.message);
        });
    }

    function displayPaymentSuccess() {
      alert('Payment Successful!');
      // Add your own logic to handle payment success
    }

    function displayPaymentError(errorMessage) {
      alert('Payment Error: ' + errorMessage);
      // Add your own logic to handle payment errors
    }
   
var myHeaders = new Headers();
myHeaders.append("X-Reference-Id", "15284da8-9169-448b-b1aa-d71080b9e6eb");
myHeaders.append("X-Target-Environment", "sandbox");
myHeaders.append("Ocp-Apim-Subscription-Key", "f4f2da18c0db4033b897644dc8ef1fec");
myHeaders.append("Content-Type", "application/json");
myHeaders.append("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSMjU2In0.eyJjbGllbnRJZCI6ImVlMDEyOGE2LTk2MjUtNDA0OS04MTlhLWRkMzRmNTBiZmVjMCIsImV4cGlyZXMiOiIyMDE5LTExLTIxVDAwOjU4OjI4LjEzNiIsInNlc3Npb25JZCI6IjUxNzlhMmM2LTM5ZmYtNGEyYS1hYjlmLTgxMTc5ZDlkYzgxYyJ9.NSSbFcW6l-1yifgYL5eWM0ALyls6ncdNvfqu4iVDrssMvRpQ3LKF2Zl7t2r3kcF07J23ulPdP66ZuK4-dDxdk1OoOsOaIq_-nFpT94joIYGcNFZ1xcsBRIe7PMzZDU9Ln1Njc6NBVY6knV-wMUYzcW0j7kqX9Knov5nX5TmeSdcYUsSa1t4JkHWk5Ok8nQcJqYrw8DlPALV1FxyMIhLhk3SeTVNTigeR0wIbUBYbjoK0ezF9fY0SLNvwfcI97AO2tY8thSVO0GDWw9FY1Y-Xx-398La5FgHGYOV8Ra7Cd0r5PiPi2e88hLfaF6WYgVZpUeKsD9G53twzFYXeZYLBJg");

var myHeaders = new Headers();
myHeaders.append("X-Reference-Id", "ee0128a6-9625-4049-819a-dd34f50bfec0");
myHeaders.append("Ocp-Apim-Subscription-Key", "98dded9b14af4ad68a778d93949284fc");
myHeaders.append("Content-Type", "application/json");

var raw = JSON.stringify({
  "providerCallbackHost": "https://webhook.site/37b4b85e-8c15-4fe5-9076-b7de3071b85d"
});

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: raw,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/v1_0/apiuser", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));


// get created user
var raw = JSON.stringify({
  "amount": "5.0",
  "currency": "EUR",
  "externalId": "6353636",
  "payer": {
    "partyIdType": "MSISDN",
    "partyId": "0248888736"
  },
  "payerMessage": "Pay for product a",
  "payeeNote": "payer note"
});

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: raw,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/collection/v1_0/requesttopay", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));

// generating api token
var myHeaders = new Headers();
myHeaders.append("Ocp-Apim-Subscription-Key", "f4f2da18c0db4033b897644dc8ef1fec");
myHeaders.append("X-Target-Environment", "sandbox");
myHeaders.append("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSMjU2In0.eyJjbGllbnRJZCI6ImVlMDEyOGE2LTk2MjUtNDA0OS04MTlhLWRkMzRmNTBiZmVjMCIsImV4cGlyZXMiOiIyMDE5LTExLTIxVDAwOjU4OjI4LjEzNiIsInNlc3Npb25JZCI6IjUxNzlhMmM2LTM5ZmYtNGEyYS1hYjlmLTgxMTc5ZDlkYzgxYyJ9.NSSbFcW6l-1yifgYL5eWM0ALyls6ncdNvfqu4iVDrssMvRpQ3LKF2Zl7t2r3kcF07J23ulPdP66ZuK4-dDxdk1OoOsOaIq_-nFpT94joIYGcNFZ1xcsBRIe7PMzZDU9Ln1Njc6NBVY6knV-wMUYzcW0j7kqX9Knov5nX5TmeSdcYUsSa1t4JkHWk5Ok8nQcJqYrw8DlPALV1FxyMIhLhk3SeTVNTigeR0wIbUBYbjoK0ezF9fY0SLNvwfcI97AO2tY8thSVO0GDWw9FY1Y-Xx-398La5FgHGYOV8Ra7Cd0r5PiPi2e88hLfaF6WYgVZpUeKsD9G53twzFYXeZYLBJg");

var requestOptions = {
  method: 'GET',
  headers: myHeaders,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/collection/v1_0/requesttopay/15284da8-9169-448b-b1aa-d71080b9e6eb", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));

// get api key
var myHeaders = new Headers();
myHeaders.append("Ocp-Apim-Subscription-Key", "f4f2da18c0db4033b897644dc8ef1fec");
myHeaders.append("X-Target-Environment", "sandbox");
myHeaders.append("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSMjU2In0.eyJjbGllbnRJZCI6ImVlMDEyOGE2LTk2MjUtNDA0OS04MTlhLWRkMzRmNTBiZmVjMCIsImV4cGlyZXMiOiIyMDE5LTExLTIxVDAwOjU4OjI4LjEzNiIsInNlc3Npb25JZCI6IjUxNzlhMmM2LTM5ZmYtNGEyYS1hYjlmLTgxMTc5ZDlkYzgxYyJ9.NSSbFcW6l-1yifgYL5eWM0ALyls6ncdNvfqu4iVDrssMvRpQ3LKF2Zl7t2r3kcF07J23ulPdP66ZuK4-dDxdk1OoOsOaIq_-nFpT94joIYGcNFZ1xcsBRIe7PMzZDU9Ln1Njc6NBVY6knV-wMUYzcW0j7kqX9Knov5nX5TmeSdcYUsSa1t4JkHWk5Ok8nQcJqYrw8DlPALV1FxyMIhLhk3SeTVNTigeR0wIbUBYbjoK0ezF9fY0SLNvwfcI97AO2tY8thSVO0GDWw9FY1Y-Xx-398La5FgHGYOV8Ra7Cd0r5PiPi2e88hLfaF6WYgVZpUeKsD9G53twzFYXeZYLBJg");

var requestOptions = {
  method: 'GET',
  headers: myHeaders,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/collection/v1_0/account/balance", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));


var myHeaders = new Headers();
myHeaders.append("X-Target-Environment", "sandbox");
myHeaders.append("Ocp-Apim-Subscription-Key", "f4f2da18c0db4033b897644dc8ef1fec");
myHeaders.append("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSMjU2In0.eyJjbGllbnRJZCI6ImVlMDEyOGE2LTk2MjUtNDA0OS04MTlhLWRkMzRmNTBiZmVjMCIsImV4cGlyZXMiOiIyMDE5LTExLTIxVDAwOjU4OjI4LjEzNiIsInNlc3Npb25JZCI6IjUxNzlhMmM2LTM5ZmYtNGEyYS1hYjlmLTgxMTc5ZDlkYzgxYyJ9.NSSbFcW6l-1yifgYL5eWM0ALyls6ncdNvfqu4iVDrssMvRpQ3LKF2Zl7t2r3kcF07J23ulPdP66ZuK4-dDxdk1OoOsOaIq_-nFpT94joIYGcNFZ1xcsBRIe7PMzZDU9Ln1Njc6NBVY6knV-wMUYzcW0j7kqX9Knov5nX5TmeSdcYUsSa1t4JkHWk5Ok8nQcJqYrw8DlPALV1FxyMIhLhk3SeTVNTigeR0wIbUBYbjoK0ezF9fY0SLNvwfcI97AO2tY8thSVO0GDWw9FY1Y-Xx-398La5FgHGYOV8Ra7Cd0r5PiPi2e88hLfaF6WYgVZpUeKsD9G53twzFYXeZYLBJg");

var requestOptions = {
  method: 'GET',
  headers: myHeaders,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/collection/v1_0/accountholder/msisdn/0243656543/active", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));

// Disbursement product.
// trasnfer status.
var myHeaders = new Headers();
myHeaders.append("X-Reference-Id", "07c40d0b-ec98-449c-9de0-d14cc3e90ed8");
myHeaders.append("X-Target-Environment", "sandbox");
myHeaders.append("Ocp-Apim-Subscription-Key", "98dded9b14af4ad68a778d93949284fc");
myHeaders.append("Content-Type", "application/json");
myHeaders.append("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSMjU2In0.eyJjbGllbnRJZCI6ImVlMDEyOGE2LTk2MjUtNDA0OS04MTlhLWRkMzRmNTBiZmVjMCIsImV4cGlyZXMiOiIyMDE5LTExLTIxVDAwOjU4OjI4LjEzNiIsInNlc3Npb25JZCI6IjUxNzlhMmM2LTM5ZmYtNGEyYS1hYjlmLTgxMTc5ZDlkYzgxYyJ9.NSSbFcW6l-1yifgYL5eWM0ALyls6ncdNvfqu4iVDrssMvRpQ3LKF2Zl7t2r3kcF07J23ulPdP66ZuK4-dDxdk1OoOsOaIq_-nFpT94joIYGcNFZ1xcsBRIe7PMzZDU9Ln1Njc6NBVY6knV-wMUYzcW0j7kqX9Knov5nX5TmeSdcYUsSa1t4JkHWk5Ok8nQcJqYrw8DlPALV1FxyMIhLhk3SeTVNTigeR0wIbUBYbjoK0ezF9fY0SLNvwfcI97AO2tY8thSVO0GDWw9FY1Y-Xx-398La5FgHGYOV8Ra7Cd0r5PiPi2e88hLfaF6WYgVZpUeKsD9G53twzFYXeZYLBJg");

var raw = JSON.stringify({
  "amount": "1000.0",
  "currency": "EUR",
  "externalId": "15234353",
  "payee": {
    "partyIdType": "MSISDN",
    "partyId": "0245565634"
  },
  "payerMessage": "June Salary",
  "payeeNote": "Any thing we want to type."
});

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: raw,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/disbursement/v1_0/transfer", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));

// account balance
var myHeaders = new Headers();
myHeaders.append("Ocp-Apim-Subscription-Key", "98dded9b14af4ad68a778d93949284fc");
myHeaders.append("X-Target-Environment", "sandbox");
myHeaders.append("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSMjU2In0.eyJjbGllbnRJZCI6ImVlMDEyOGE2LTk2MjUtNDA0OS04MTlhLWRkMzRmNTBiZmVjMCIsImV4cGlyZXMiOiIyMDE5LTExLTIxVDAwOjU4OjI4LjEzNiIsInNlc3Npb25JZCI6IjUxNzlhMmM2LTM5ZmYtNGEyYS1hYjlmLTgxMTc5ZDlkYzgxYyJ9.NSSbFcW6l-1yifgYL5eWM0ALyls6ncdNvfqu4iVDrssMvRpQ3LKF2Zl7t2r3kcF07J23ulPdP66ZuK4-dDxdk1OoOsOaIq_-nFpT94joIYGcNFZ1xcsBRIe7PMzZDU9Ln1Njc6NBVY6knV-wMUYzcW0j7kqX9Knov5nX5TmeSdcYUsSa1t4JkHWk5Ok8nQcJqYrw8DlPALV1FxyMIhLhk3SeTVNTigeR0wIbUBYbjoK0ezF9fY0SLNvwfcI97AO2tY8thSVO0GDWw9FY1Y-Xx-398La5FgHGYOV8Ra7Cd0r5PiPi2e88hLfaF6WYgVZpUeKsD9G53twzFYXeZYLBJg");

var requestOptions = {
  method: 'GET',
  headers: myHeaders,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/disbursement/v1_0/account/balance", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));

// check if user is registered.
var myHeaders = new Headers();
myHeaders.append("X-Target-Environment", "sandbox");
myHeaders.append("Ocp-Apim-Subscription-Key", "98dded9b14af4ad68a778d93949284fc");
myHeaders.append("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSMjU2In0.eyJjbGllbnRJZCI6ImVlMDEyOGE2LTk2MjUtNDA0OS04MTlhLWRkMzRmNTBiZmVjMCIsImV4cGlyZXMiOiIyMDE5LTExLTIxVDAwOjU4OjI4LjEzNiIsInNlc3Npb25JZCI6IjUxNzlhMmM2LTM5ZmYtNGEyYS1hYjlmLTgxMTc5ZDlkYzgxYyJ9.NSSbFcW6l-1yifgYL5eWM0ALyls6ncdNvfqu4iVDrssMvRpQ3LKF2Zl7t2r3kcF07J23ulPdP66ZuK4-dDxdk1OoOsOaIq_-nFpT94joIYGcNFZ1xcsBRIe7PMzZDU9Ln1Njc6NBVY6knV-wMUYzcW0j7kqX9Knov5nX5TmeSdcYUsSa1t4JkHWk5Ok8nQcJqYrw8DlPALV1FxyMIhLhk3SeTVNTigeR0wIbUBYbjoK0ezF9fY0SLNvwfcI97AO2tY8thSVO0GDWw9FY1Y-Xx-398La5FgHGYOV8Ra7Cd0r5PiPi2e88hLfaF6WYgVZpUeKsD9G53twzFYXeZYLBJg");

var requestOptions = {
  method: 'GET',
  headers: myHeaders,
  redirect: 'follow'
};

fetch("https://sandbox.momodeveloper.mtn.com/disbursement/v1_0/accountholder/msisdn/0243656043/active", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));




  
const PaymentForm = document.getElementById('paymentForm');

    paymentForm.addEventListener('submit', function(event) {
      event.preventDefault();

      const cardNumber = document.getElementById('cardNumber').value;
      const expirationDate = document.getElementById('expirationDate').value;
      const cvv = document.getElementById('cvv').value;
      const amount = document.getElementById('amount').value;

      const paymentData = {
        cardNumber: cardNumber,
        expirationDate: expirationDate,
        cvv: cvv,
        amount: amount
      };

      // Call the payment gateway API to process the Visa card payment
      makeVisaCardPayment(paymentData);
    });

    function makeVisaCardPayment(paymentData) {

      // Send the paymentData object as the payload to the payment gateway API
      fetch('https://api.paymentgateway.com/payments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(paymentData)
      })
      .then(response => response.json())
      .then(data => {
        // Process the payment response
        if (data.success) {
          // Payment was successful
          displayPaymentSuccess(data.transactionId);
        } else {
          // Payment failed
          displayPaymentError(data.errorMessage);
        }
      })
      .catch(error => {
        // Handle any errors
        displayPaymentError(error.message);
      });
    }

    function displayPaymentSuccess(transactionId) {
      const result = document.getElementById('result');
      result.innerHTML = `Payment Successful! Transaction ID: ${transactionId}`;
      result.style.color = 'green';
    }

    function displayPaymentError(errorMessage) {
      const result = document.getElementById('result');
      result.innerHTML = `Payment Failed: ${errorMessage}`;
      result.style.color = 'red';
    }

const paymentForm = document.getElementById('paymentForm');

    paymentForm.addEventListener('submit', function(event) {
      event.preventDefault();

      const expirationDateInput = document.getElementById('expirationDate').value;

      const [month, year] = expirationDateInput.split('/');

      // Use month and year for further processing
      console.log('Month:', month);
      console.log('Year:', year);

    });
function submitForm(event) {
      event.preventDefault(); // Prevent form submission

      // Get form values
      var name = document.getElementById("name").value;
      var email = document.getElementById("email").value;
      var phone = document.getElementById("phone").value;

      // Create a new XMLHttpRequest object
      var xhr = new XMLHttpRequest();
      
      // Prepare the request
      xhr.open("POST", "process-registration.php", true);
      xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      
      // Define the request parameters
      var params = "name=" + encodeURIComponent(name) + "&email=" + encodeURIComponent(email) + "&phone=" + encodeURIComponent(phone);
      
      // Handle the response from the server
      xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
          // Display a success message or perform any other desired actions
          alert("Registration successful!");
          
          // Clear the form fields
          document.getElementById("name").value = "";
          document.getElementById("email").value = "";
          document.getElementById("phone").value = "";
          document.getElementById("address").value = "";
        }
      };
      
      // Send the request
      xhr.send(params);
    }

const response = axios.post("/api/v1/orders", {
  Name,
  PhoneNumber,
    Email,
    Address,
});
console.log(response);
toast.success("order placed successfully");
dispatch(clear());

axios
.get(PaymentRequest)
.then((res)) {
  console.log("payment resquest with id",res)
};
